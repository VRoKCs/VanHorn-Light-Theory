﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bullet : MonoBehaviour {
    public GameObject bullet2;

	// Use this for initialization
	void Start () {
		
	}

    // Update is called once per frame
    void Update(){
        Destroy(bullet2, 5);  
    }
}
