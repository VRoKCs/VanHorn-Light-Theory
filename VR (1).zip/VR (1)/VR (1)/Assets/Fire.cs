﻿using UnityEngine;
using System.Collections;

public class Fire: MonoBehaviour
{
    public GameObject Bulletemeter;
    public GameObject bullet;

    void Start()
    {
       
    }

    void Update()
    {
        if (Input.GetButtonDown("Fire1"))
        {
            Shoot();
        }
    }

    public void Shoot()
    {
        GameObject temp = Instantiate(bullet, transform.position, new Quaternion());
        Rigidbody rigid = temp.GetComponent<Rigidbody>();
        rigid.AddForce(Bulletemeter.transform.rotation * new Vector3(0, 0, 10), ForceMode.VelocityChange);
    }
}