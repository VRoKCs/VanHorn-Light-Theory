﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class colition : MonoBehaviour {

    private void OnCollisionEnter(Collision collision)
    {
        // You probably want a check here to make sure you're hitting a zombie
        // Note that this is not the best method for doing so.
        if (collision.gameObject.name == "bullet(Clone)")
        {
            Destroy(collision.gameObject);
        }
    }
}
